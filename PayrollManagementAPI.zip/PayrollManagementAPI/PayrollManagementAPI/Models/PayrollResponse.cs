﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace PayrollManagementAPI.Models
{
    public class PayrollResponse
    {
        public int EmployeeId { get; set; }

        public string EmployeeName { get; set; }

        public string Department { get; set; }

        public decimal Salary { get; set; }

        public decimal BonusPercentage { get; set; }

        public decimal BonusAmount { get; set; }

        public decimal TotalSalary { get; set; }
    }
}