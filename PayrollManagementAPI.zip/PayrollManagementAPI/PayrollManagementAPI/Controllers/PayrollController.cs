﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using PayrollManagementAPI.Models;

public class PayrollController : ApiController
{
    [HttpGet]
    [Route("api/Payroll/EmployeeSalary/{id:int}")]
    public async Task<IHttpActionResult> EmployeeSalary(int id)
    {
        try
        {
            using (HttpClient client = new HttpClient())
            {
                // Step 1: Call Project 1 API
                string apiUrl =
                    "http://localhost:58081/api/Employee/" + id;

                HttpResponseMessage response =
                    await client.GetAsync(apiUrl);

                // Step 2: Check API response
                if (!response.IsSuccessStatusCode)
                {
                    return StatusCode(response.StatusCode);
                }

                // Step 3: Convert JSON into Employee object
                Employee employee =
                    await response.Content.ReadAsAsync<Employee>();

                if (employee == null)
                {
                    return InternalServerError();
                }

                // Step 4: Apply our business logic
                decimal bonusPercentage = 10;

                decimal bonusAmount =
                    employee.Salary * bonusPercentage / 100;

                decimal totalSalary =
                    employee.Salary + bonusAmount;

                // Step 5: Create our own response
                PayrollResponse payroll = new PayrollResponse
                {
                    EmployeeId = employee.EmployeeId,
                    EmployeeName = employee.EmployeeName,
                    Department = employee.Department,
                    Salary = employee.Salary,
                    BonusPercentage = bonusPercentage,
                    BonusAmount = bonusAmount,
                    TotalSalary = totalSalary
                };

                // Step 6: Return response
                return Ok(payroll);
            }
        }
        catch (Exception ex)
        {
            return InternalServerError(ex);
        }
    }
}