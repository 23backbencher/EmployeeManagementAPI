﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using EmployeeManagementAPI.Models;

namespace EmployeeManagementAPI.Controllers
{
    public class EmployeeController : ApiController
    {
        // Demo data
        private static List<Employee> employees =
            new List<Employee>
        {
            new Employee
            {
                EmployeeId = 101,
                EmployeeName = "Ramesh",
                Department = "IT",
                Salary = 45000
            },
            new Employee
            {
                EmployeeId = 102,
                EmployeeName = "Suresh",
                Department = "Finance",
                Salary = 50000
            }
        };

        // GET: api/Employee
        public IHttpActionResult Get()
        {
            return Ok(employees);
        }

        // GET: api/Employee/101
        public IHttpActionResult Get(int id)
        {
            var employee = employees
                .FirstOrDefault(x => x.EmployeeId == id);

            if (employee == null)
                return NotFound();

            return Ok(employee);
        }

        // POST: api/Employee
        public IHttpActionResult Post(Employee employee)
        {
            employee.EmployeeId =
                employees.Max(x => x.EmployeeId) + 1;

            employees.Add(employee);

            return Ok(employee);
        }

        // PUT: api/Employee/101
        public IHttpActionResult Put(int id, Employee updated)
        {
            var employee = employees
                .FirstOrDefault(x => x.EmployeeId == id);

            if (employee == null)
                return NotFound();

            employee.EmployeeName = updated.EmployeeName;
            employee.Department = updated.Department;
            employee.Salary = updated.Salary;

            return Ok(employee);
        }

        // DELETE: api/Employee/101
        public IHttpActionResult Delete(int id)
        {
            var employee = employees
                .FirstOrDefault(x => x.EmployeeId == id);

            if (employee == null)
                return NotFound();

            employees.Remove(employee);

            return Ok("Employee deleted successfully");
        }
    }
}